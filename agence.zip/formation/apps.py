from django.apps import AppConfig


class FormationConfig(AppConfig):
    name = 'formation'
